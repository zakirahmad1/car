<table width="100%">
		<tbody>
			<tr>
				<td>
					<table width="600px" align="center">
						<tbody>
							<tr>
								<td>
									<div style="border-radius:11px 11px 10px 10px;border:1px solid #dddddd;border-color:rgba(0,0,0,0.13);background-color:#fff">
										<div style="border-radius:10px 10px 0 0;font-family:'Helvetica Neue',Arial,sans-serif;font-size:24px;background-color:#00aeec;padding:17px 20px 13px;color:#fff;font-weight:bold">
											<span style="font-size:18px;font:Helvetica Neue;color:#ffffff;display:inline-block;line-height:25pt;margin-right:1em">
												<img alt="Details">
											</span>
										</div>
										<div style="padding:15px">
											<br>
											<div style="font-family:'Helvetica Heue',Arial,sans-serif;font-size:14px;line-height:18px">
											Hi <?php echo $first_name;?>,
											<br><br>
											<p>Your email:<?php echo $email;?></p>
											<p>Password:<?php echo $password;?></p>
											<p><a href="<?=site_url(array('user'))?>"> login</a></p>

											
											<br><br>
											Team,
											<br><br>
											Thanks

											
											<br>
											<br>
											</div>
										</div>
									
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</td>
</tr>
</tbody>
</table>

