<div class="text-center mt-5 text-muted">
						Copyright &copy; 2017-2021 &mdash; Your Company 
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="<?=base_url(array('assets','light',"js","login.js"))?>"></script>
</body>
</html>
